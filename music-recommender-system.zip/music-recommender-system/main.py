import streamlit as st
import pickle
import pandas as pd
from sklearn.neighbors import NearestNeighbors


def recommend(music):
    music = music.lower()
    song_index = music_list.index[music_list['song_name'] == music].tolist()[0]
    print(song_index)
    print(song_features.index[song_index])
    distances, indices = model_nn.kneighbors(X=song_features.iloc[song_index, :].values.reshape(1, -1), n_neighbors=6)

    recommended_movies = []
    for i in range(0, len(distances.flatten())):
        if i == 0:
            recommended_movies.append('The recommended music are:')
        else:
            recommended_movies.append(song_features.index[indices.flatten()[i]])
    return recommended_movies


music_list = pickle.load(open('music.pkl', 'rb'))

song_features = pickle.load(open('song_features.pkl', 'rb'))
# csr = pickle.load(open('csr.pkl', 'rb'))


from scipy.sparse import csr_matrix
song_features_csr = csr_matrix(song_features.values)


# model_nn = pickle.load(open('model_nn.pkl', 'rb'))
model_nn = NearestNeighbors(metric='cosine', algorithm='brute')
model_nn.fit(song_features_csr)

st.title("Music Recommendation System")

selected_movie_name = st.selectbox(
    'Select or Search the music for recommendation',
    music_list['song_name'].values
)

if st.button('Recommend'):
    recommendations = recommend(selected_movie_name)
    for i in recommendations:
        st.write(i)
